package SignUpCheckoutAutomation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class MyTestSuite 
{
	public WebDriver driver;
	Select stateSelect,countrySelect;
	String inStock="In stock";
	
  @Test(priority=1)
  public void signup() 
  {
	     //Creating account
		 driver.findElement(By.cssSelector("a.login")).click();
		 driver.findElement(By.xpath("//input[@id='email_create']")).sendKeys("abcdefghi199222@gmail.com");
		 driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();
		 
		 //Provide account details
		 String createAccountUrl=driver.getCurrentUrl();
		 System.out.println(createAccountUrl);
		 
		 driver.findElement(By.cssSelector("input#id_gender2")).click();
		 driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("abc");
		 driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("xyz");
		 driver.findElement(By.cssSelector("input#passwd")).sendKeys("mypassword");
		 driver.findElement(By.cssSelector("input#address1")).sendKeys("My address");
		 driver.findElement(By.cssSelector("input#city")).sendKeys("My City");
		 
		 stateSelect=new Select(driver.findElement(By.cssSelector("select#id_state")));
		 stateSelect.selectByVisibleText("Alaska");
		 driver.findElement(By.cssSelector("input#postcode")).sendKeys("1126");                //Invalid postcode
		 driver.findElement(By.cssSelector("input#phone_mobile")).sendKeys("12345678");
		 //driver.findElement(By.cssSelector("input#alias")).sendKeys("My address");
		 driver.findElement(By.cssSelector("button#submitAccount")).click();
		 
		 //Check if error message occurs if invalid postcode is given
		 String errMsg=driver.findElement(By.xpath("//*[@id='center_column']/div/ol/li")).getText();
		 Assert.assertEquals(errMsg,"The Zip/Postal code you've entered is invalid. It must follow this format: 00000");
		 driver.findElement(By.cssSelector("input#postcode")).clear();
		 driver.findElement(By.cssSelector("input#passwd")).sendKeys("mypassword");            //Reenter password
		 driver.findElement(By.cssSelector("input#postcode")).sendKeys("11261");               //Valid postcode
		 driver.findElement(By.cssSelector("button#submitAccount")).click();	 
		
  }
  
 public void addItemToCart()
  {
	     //Add item to cart
		 
		 WebElement category=driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/a"));
		 Actions action1=new Actions(driver);
		 action1.moveToElement(category).build().perform();
		 WebDriverWait wait = new WebDriverWait(driver, 30);
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[2]/ul/li[2]/a"))).click();;
		 if((driver.findElement(By.xpath("//*[@id=\'center_column\']/ul/li[1]/div/div[2]/span/span")).getText()).equals(inStock))
		 {
			 System.out.println("In stock");
			 WebElement item=driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[1]/div/a[1]/img"));
			 Actions action2=new Actions(driver);
			 action2.moveToElement(item).build().perform();
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='center_column']/ul/li[1]/div/div[2]/div[2]/a[1]"))).click();
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='layer_cart']/div[1]/div[2]/div[4]/a"))).click();
			 //driver.findElement(By.xpath("//*[@id='layer_cart']/div[1]/div[2]/div[4]/a")).click();
			 driver.findElement(By.xpath("//*[@id='center_column']/p[2]/a[1]")).click();
			 driver.findElement(By.xpath("//*[@id='center_column']/form/p/button")).click();
			 driver.findElement(By.cssSelector("input#cgv")).click();
			 driver.findElement(By.xpath("//*[@id='form']/p/button")).click();
		 }
		 else
			 System.out.println("Item Not Available");
  }
  
  @Test(priority=2)
  public void checkoutByBankwire()
  {
	  addItemToCart();
	  driver.findElement(By.cssSelector("a.bankwire")).click();
		 driver.findElement(By.xpath("//*[@id='cart_navigation']/button")).click();
		 System.out.println(driver.findElement(By.cssSelector("div.box")).getText());
  }
  
  @Test(priority=3)
  public void checkoutByCheque()
  {
	  addItemToCart();
	  driver.findElement(By.cssSelector("a.cheque")).click();
	  driver.findElement(By.xpath("//*[@id='cart_navigation']/button")).click();
	  System.out.println(driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[1]")).getText());
  }

  @BeforeSuite
  public void beforeSuite() 
  {
	  	 //Launch chrome browser and direct it to given url
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\gaurangi\\Desktop\\Udemy Selenium Programs\\PrimePhonicAssignmment\\chromedriver.exe");
		 driver=new ChromeDriver(); 
		 
		 //Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 driver.get("http://automationpractice.com/");
		 driver.manage().window().maximize();
  }
  
  @AfterSuite
  public void afterSuite()
  {
	  driver.quit();               
  }
}
